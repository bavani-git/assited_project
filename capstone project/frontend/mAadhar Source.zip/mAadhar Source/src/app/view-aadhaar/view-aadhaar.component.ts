import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-view-aadhaar',
  templateUrl: './view-aadhaar.component.html',
  styleUrls: ['./view-aadhaar.component.css']
})
export class ViewAadhaarComponent implements OnInit {

  constructor(public ser:UserServiceService,router:Router) { }
  info:any
 
  ngOnInit(): void {
    let s=sessionStorage.getItem("user");
    if(s!=null){
      console.log(s)
      this.ser.getInfo(s).subscribe({
        next:(obj:any)=>{
        console.log(obj);
        this.info=obj;},
        error:(err)=>console.log(err),
        complete:()=>console.log("completed")
      })
      
    }
    else{
      console.log(s);
    }
      
  }

}
