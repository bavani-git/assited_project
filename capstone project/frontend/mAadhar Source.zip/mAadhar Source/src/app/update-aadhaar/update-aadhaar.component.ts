import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AadhaarInfo } from '../aadhaar-info';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-update-aadhaar',
  templateUrl: './update-aadhaar.component.html',
  styleUrls: ['./update-aadhaar.component.css']
})
export class UpdateAadhaarComponent implements OnInit {

  constructor(public ser:UserServiceService,router:Router) { }
  info:any
  address:any
  mobileNo:any
  date:any
  msg:string=""
  ngOnInit(): void {
    let s=sessionStorage.getItem("user");
    if(s!=null){
      console.log(s)
      this.ser.getInfo(s).subscribe({
        next:(obj:any)=>{
        console.log(obj);
        this.info=obj;
        this.address=this.info.address;
        this.mobileNo=this.info.mobileNo;
        this.date=this.info.date;
      },
        error:(err)=>console.log(err),
        complete:()=>console.log("completed")
      })
  }
}

update()
{
 let info= new AadhaarInfo(this.info.emailid,this.info.aid,this.info.name,this.address,this.mobileNo,this.info.gender,this.date,this.info.status);
 console.log(info);
  this.ser.usrUpdate(info).subscribe({
    next:(obj:any)=>{
    console.log(obj);
    this.msg=obj;},
    error:(err)=>console.log(err),
    complete:()=>console.log("completed")
  });
}

}
