import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAadhaarComponent } from './update-aadhaar.component';

describe('UpdateAadhaarComponent', () => {
  let component: UpdateAadhaarComponent;
  let fixture: ComponentFixture<UpdateAadhaarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateAadhaarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateAadhaarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
