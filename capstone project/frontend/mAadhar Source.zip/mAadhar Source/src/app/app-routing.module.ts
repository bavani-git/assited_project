import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminDuplicateComponent } from './admin-duplicate/admin-duplicate.component';
import { AdminRequestComponent } from './admin-request/admin-request.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminviewComponent } from './adminview/adminview.component';
import { ApplyAadhaarComponent } from './apply-aadhaar/apply-aadhaar.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UpdateAadhaarComponent } from './update-aadhaar/update-aadhaar.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { ViewAadhaarComponent } from './view-aadhaar/view-aadhaar.component';

const routes: Routes = [
  {path: '',component:LoginComponent},
  {path: 'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'adminin',component:AdminloginComponent},
  
  {path:'userdash',component:UserDashboardComponent},
  {path:'apply',component:ApplyAadhaarComponent},
  {path:'view',component:ViewAadhaarComponent},

  {path:'admindash',component:AdminDashboardComponent},
  {path:'updateu',component:UpdateAadhaarComponent},
  {path:'viewreq',component:AdminRequestComponent},
  {path:'dupreq',component:AdminDuplicateComponent},
  {path:'viewinfo',component:AdminviewComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
