import { AadhaarInfo } from './aadhaar-info';

describe('AadhaarInfo', () => {
  it('should create an instance', () => {
    expect(new AadhaarInfo()).toBeTruthy();
  });
});
