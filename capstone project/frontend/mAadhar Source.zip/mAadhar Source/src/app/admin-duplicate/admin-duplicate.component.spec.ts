import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDuplicateComponent } from './admin-duplicate.component';

describe('AdminDuplicateComponent', () => {
  let component: AdminDuplicateComponent;
  let fixture: ComponentFixture<AdminDuplicateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminDuplicateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminDuplicateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
