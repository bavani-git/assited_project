import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AadhaarInfo } from './aadhaar-info';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  //baseurl="http://localhost:8050/login/";
  constructor(public http:HttpClient) {}
  
  usrRegister(user:any):Observable<string>
  {
    console.log(user);
    return this.http.post("http://localhost:8050/login/signup",user,{responseType:"text"});
    
  }

  usrLogin(user:any):Observable<string>
  {
    console.log(user);
    return this.http.post("http://localhost:8050/login/signin",user,{responseType:"text"});
  }

  usrApply(aadhaar:any):Observable<string>
  {
    console.log(aadhaar);
    return this.http.post("http://localhost:8050/user/apply",aadhaar,{responseType:"text"});
  }

  getInfo(email:any):Observable<any>
  {
      return this.http.get("http://localhost:8050/user/getinfo/"+email);
  }

  usrUpdate(AadhaarInfo:any):Observable<String>
  {
    return this.http.patch("http://localhost:8050/user/update",AadhaarInfo,{responseType:"text"});
  }

  usrDuplicate(email:string):Observable<any>
  {
      return this.http.get("http://localhost:8050/user/duplicate/"+email,{responseType:"text"});
  }

  adminRequest():Observable<AadhaarInfo[]>
  {
      return this.http.get<AadhaarInfo[]>("http://localhost:8050/admin/request");
  }

  adminDuplicate():Observable<AadhaarInfo[]>
  {
    return this.http.get<AadhaarInfo[]>("http://localhost:8050/admin/duplicate");
  }

  adminView():Observable<AadhaarInfo[]>
  {
    return this.http.get<AadhaarInfo[]>("http://localhost:8050/admin/all");
  }

  admindelete(email:any):Observable<string>
  {
    return this.http.patch<string>("http://localhost:8050/admin/delete/"+email,{responseType:"text"});
  }

  adminUpdate(update:any):Observable<any>
  {
    console.log(update)
    return this.http.patch("http://localhost:8050/admin/update",update,{responseType:"text"});
  }
}
