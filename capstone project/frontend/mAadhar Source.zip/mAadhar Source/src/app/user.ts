export class User {

    constructor(public emailid:string,public password:string,public role:string,public phno:number)
    {

    }
}
