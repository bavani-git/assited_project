import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

  constructor(public ser:UserServiceService,public router:Router) { }
  usr:any;
  ngOnInit(): void {
    this.usr=sessionStorage.getItem("user");
  }

  dup()
  {
    console.log(this.usr);
    this.ser.usrDuplicate(this.usr).subscribe({
      next:(obj:any)=>{
      console.log(obj);
      window.alert(obj)},
      error:(err)=>console.log(err),
      complete:()=>console.log("completed")
    });
  }

  logout()
  {
    sessionStorage.removeItem("user");
  }

}
