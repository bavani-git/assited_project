import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { LoginComponent } from './login/login.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ApplyAadhaarComponent } from './apply-aadhaar/apply-aadhaar.component';
import { ViewAadhaarComponent } from './view-aadhaar/view-aadhaar.component';
import { UpdateAadhaarComponent } from './update-aadhaar/update-aadhaar.component';
import { AdminRequestComponent } from './admin-request/admin-request.component';
import { AdminDuplicateComponent } from './admin-duplicate/admin-duplicate.component';
import { AdminviewComponent } from './adminview/adminview.component';
//import { NavComponent } from './nav/nav.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    LoginComponent,
    AdminloginComponent,
    ApplyAadhaarComponent,
    ViewAadhaarComponent,
    UpdateAadhaarComponent,
    AdminRequestComponent,
    AdminDuplicateComponent,
    AdminviewComponent,
   // NavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,ReactiveFormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
