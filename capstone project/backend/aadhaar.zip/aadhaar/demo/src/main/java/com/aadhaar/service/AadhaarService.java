package com.aadhaar.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aadhaar.bean.AadhaarInfo;
import com.aadhaar.repository.AadhaarRepository;

@Service
public class AadhaarService {

	@Autowired
	AadhaarRepository ar;
	public String apply(AadhaarInfo a)
	{
		Optional<AadhaarInfo> result = ar.findById(a.getEmailid());
		if(!result.isPresent())
		{
			ar.save(a);
			return "request is Successfull";
		}
		else
		{
			if(result.get().getStatus().equals("approved"))
			{
				return "Aadhaar is approved and active";
			}
			else if(result.get().getStatus().equals("pending"))
			{
				return "Aadhaar is Pending to activate";
			}
			else
			{
				ar.save(a);
				return "Previous Request was Cancelled ... please apply again.";
			}
			
		}

		
				
	}
	
	public AadhaarInfo requestData(String email)
	{
		Optional<AadhaarInfo> result = ar.findById(email);
		
		
			return result.get();
	
			
		
		
	}
	
	public String update(AadhaarInfo a)
	{
		if(a!=null)
		{
			
		try {
			ar.saveAndFlush(a);
			return "update Successful";
		} catch (Exception e) {
			
			return "request failed";
		}
		}
			return "request failed";
	
	}
	
	public String delete(AadhaarInfo a)
	{
		try {
			ar.delete(a);
			return "deleted Successfully";
		} catch (Exception e) {
			
			e.printStackTrace();
			return "unsuccessful";
		}
	}
	
	public String requestDuplicate(String email )
	{
		Optional<AadhaarInfo> result = ar.findById(email);
		if(result.isPresent())
		{
			result.get().setStatus("duplicate");
			ar.saveAndFlush(result.get());
			return "Request Successful";
		}
		return "Request failed";
	}
}
